﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PhoneOperator.Classes;

namespace PhoneOperator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPagq.xaml
    /// </summary>
    public partial class AddEditPagq : Page
    {
        private Student _currentperson = new Student(); //экземпляр добавляемого пользователя
        public AddEditPagq(Student selectedUser) // в конструктор добавлен праметр типа User
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentperson = selectedUser;
            DataContext = _currentperson;
        }

        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.FirstName))
                error.AppendLine("Укажите имя");
            if (string.IsNullOrWhiteSpace(_currentperson.SurName))
                error.AppendLine("Укажите Фамилию");
            if (string.IsNullOrWhiteSpace(patron.Text))
                error.AppendLine("Укажите Отчество");
            if (string.IsNullOrWhiteSpace(age.Text))
                error.AppendLine("Укажите дату рождения");
            if (string.IsNullOrWhiteSpace(enrollementyear.Text))
                error.AppendLine("Укажите год поступления");
            if (string.IsNullOrWhiteSpace(grants.Text))
                error.AppendLine("Укажите размер стипендии");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDStd == 0)
                StudentsDBEntities.GetContext().Student.Add(_currentperson);//Добавить в контекст
            try
            {

                StudentsDBEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void BtnPrintPerson_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {

                printDialog.PrintVisual(Gridedit, "");
                Gridedit.LayoutTransform = null;

            }
            else
            {
                MessageBox.Show("Пользователь прервал печать", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
        }
    }

}

