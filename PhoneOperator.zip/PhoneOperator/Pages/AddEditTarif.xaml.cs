﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PhoneOperator.Pages
{
    /// <summary>
    /// Interaction logic for AddEditTarif.xaml
    /// </summary>
    public partial class AddEditTarif : Page
    {
        private Tarif _currentperson = new Tarif(); //экземпляр добавляемого пользователя
        public AddEditTarif(Tarif selectedUser) // в конструктор добавлен праметр типа User
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentperson = selectedUser;
            DataContext = _currentperson;
            CmbFiltrTarifAD.ItemsSource = cellularproviderEntities.GetContext().Country.ToList();
            CmbFiltrTarifAD.SelectedValuePath = "IDCountry";
            CmbFiltrTarifAD.DisplayMemberPath = "CountryName";

        }

        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.TarifName))
                error.AppendLine("Укажите Название тарифа");
            if (string.IsNullOrWhiteSpace(price.Text))
                error.AppendLine("Укажите стоимость");
            if (string.IsNullOrWhiteSpace(internet.Text))
                error.AppendLine("Укажите количество гб");
            if (string.IsNullOrWhiteSpace(CmbFiltrTarifAD.Text))
                error.AppendLine("Укажите Страну");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDTarif == 0)
                cellularproviderEntities.GetContext().Tarif.Add(_currentperson);//Добавить в контекст
            try
            {

                cellularproviderEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void BtnPrintPerson_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {

                printDialog.PrintVisual(Gridedit, "");
                Gridedit.LayoutTransform = null;

            }
            else
            {
                MessageBox.Show("Пользователь прервал печать", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
        }

        private void CmbFiltrTarifAD_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }

}
