﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PhoneOperator.Classes;
using System.IO;
using Newtonsoft.Json;

namespace PhoneOperator.Pages
{
    /// <summary>
    /// Логика взаимодействия для TableTarif.xaml
    /// </summary>
    public partial class TableTarif : Page
    {
        public TableTarif()
        { 
            InitializeComponent();
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
            CmbFiltrTarif.ItemsSource = cellularproviderEntities.GetContext().Country.ToList();
            CmbFiltrTarif.SelectedValuePath = "IDCountry";
            CmbFiltrTarif.DisplayMemberPath = "CountryName";

        }

    private void btnEdit_Click(object sender, RoutedEventArgs e)
    //Редактирование пользователей
    {
            this.NavigationService.Navigate(new Pages.AddEditTarif((sender as Button).DataContext as Tarif));
    }

    private void BtnAdd_Click(object sender, RoutedEventArgs e)
    // Добавление пользователей
    {
            this.NavigationService.Navigate(new Pages.AddEditTarif(null)/*((Person)DGridUsers.SelectedItem)*/);
    }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        //Удаление нескольких пользователей
        var personForRemoving = DGridTarif.SelectedItems.Cast<Tarif>().ToList();
        if (MessageBox.Show($"Удалить {personForRemoving.Count()} тарифов?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
        {
            try
            {
                cellularproviderEntities.GetContext().Tarif.RemoveRange(personForRemoving);
                cellularproviderEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные удалены");
                    DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }

    private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {//Динамиеское отображение добавленных или изменённых данных
        if (Visibility == Visibility.Visible)
        {
            cellularproviderEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
        }
    }

    private void BtnResetAll_Click(object sender, RoutedEventArgs e)
    {
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.ToList();
    }

    private void CmbFiltrTarif_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        int id = Convert.ToInt32(CmbFiltrTarif.SelectedValue);
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.Where(x => x.Country.IDCountry == id).ToList();
    }

    private void RbUp_Checked(object sender, RoutedEventArgs e)
    {
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.OrderBy(x => x.TarifName).ToList();
    }

    private void RbDown_Checked(object sender, RoutedEventArgs e)
    {
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.OrderByDescending(x => x.TarifName).ToList();
    }
    private void RbChecked(object sender, RoutedEventArgs e)
        {
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.Where(x => x.Internet < 10).ToList();
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
            DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.Where(x => x.TarifName.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
    }

        private void price_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int pr1 = int.Parse(priceSearch.Text);
                DGridTarif.ItemsSource = cellularproviderEntities.GetContext().Tarif.Where(x => x.Price < pr1).ToList();
            }
            catch (Exception ex)
            {
               
                 MessageBox.Show("Ошибка ввода!", "Внимание", MessageBoxButton.OK, MessageBoxImage.Error);
                
            }


        }

        private void BtnSaveJson_Click(object sender, RoutedEventArgs e)
        {
            File.WriteAllText("input.json", string.Empty);

            foreach(Tarif nt in cellularproviderEntities.GetContext().Tarif)
            {
                Tarif Tarif = new Tarif()
                {
                    TarifName = nt.TarifName,
                    Price = nt.Price,
                    Internet = nt.Internet
                };
                File.AppendAllText("input.json", JsonConvert.SerializeObject(Tarif));
            }
        }

        private void priceJSON_Click(object sender, RoutedEventArgs e)
        {
            List<Tarif> ntttt = new List<Tarif>();//Список записок
            JsonTextReader reader = new JsonTextReader(new StreamReader("input.json"));//Открытие файла
            reader.SupportMultipleContent = true;
            while (reader.Read())//Пока не закончатся записи
            {
                JsonSerializer serializer = new JsonSerializer();
                Tarif temp_point = serializer.Deserialize<Tarif>(reader); // 1 записка
                if (temp_point.TarifName.Contains(priceSearchJSON.Text)) //Отображение по совпадению с поиском
                    ntttt.Add(temp_point);
            }
            string s = "";
            foreach (Tarif nt in ntttt)
            {
                s += nt.TarifName + " " + nt.Price + " " + nt.Internet + "\n";
            }
            MessageBox.Show(s, "Результат:");

        }
    }
}

