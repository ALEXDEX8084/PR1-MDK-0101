﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PhoneOperator.Classes
{
    public class TarifCountClass
    {
        //public string NameTarif { get; set; }
        public int CountAbonents { get; set; }
        public TarifCountClass(/*string n,*/ int c)
        {
            //this.NameTarif = n;
            this.CountAbonents = c;
        }
    }
}
